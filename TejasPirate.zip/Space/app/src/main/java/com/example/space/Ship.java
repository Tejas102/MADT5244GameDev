package com.example.space;

public class Ship {
}
